
fileName = "add_tag.mcfunction"
f = open(fileName, "w+")
for j in range(41):
    if (j == 36):
        j = 100
    elif (j == 37):
        j = 101
    elif (j == 38):
        j = 102
    elif (j == 39):
        j = 103
    elif (j == 40):
        j = -106
    data = f.read()
    f.write(data + "\ntag @s add craft_op_ench_slot_"+str(j)+"\n")
f.close()
