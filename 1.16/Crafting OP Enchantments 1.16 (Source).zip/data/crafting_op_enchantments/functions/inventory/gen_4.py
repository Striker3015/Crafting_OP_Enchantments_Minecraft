enchant = ["knockback","aqua_affinity","bane_of_arthropods","blast_protection","channeling","depth_strider","efficiency","feather_falling","fire_aspect","fire_protection","flame","fortune","frost_walker","impaling","infinity","looting","loyalty","luck_of_the_sea","lure","mending","multishot","piercing","power","projectile_protection","protection","punch","quick_charge","respiration","riptide","sharpness","silk_touch","smite","soul_speed","sweeping","thorns","unbreaking"]

for j in range(41):
    if (j == 36):
        j = 100
    elif (j == 37):
        j = 101
    elif (j == 38):
        j = 102
    elif (j == 39):
        j = 103
    elif (j == 40):
        j = -106
    fileName = "slot_"+str(j)+"/setting_item.mcfunction"
    f = open(fileName, "w+")
    f.write("\n")
    data = f.read()
    f.write(data + "function crafting_op_enchantments:get_random\nscoreboard players operation #crafting_op_enchantments_item_slot_"+str(j)+" craft_op_ench = $Random craft_op_ench\nscoreboard players operation #crafting_op_enchantments_item_slot_"+str(j)+" craft_op_ench %= #36 craft_op_ench\n")
    for i in range(36):
        i = i + 1
        data = f.read()
        f.write(data + "execute if score #crafting_op_enchantments_item_slot_"+str(j)+" craft_op_ench matches "+str(i-1)+" run function crafting_op_enchantments:enchant/enchant_"+str(i)+"/enchant_"+str(i)+"\n")
    f.close()
