import os
fileName_t = "crafted_t.mcfunction"
f_t = open(fileName_t, "r+")
data_t = f_t.read()
data_t = data_t.split("\n")

for j in range(977):
    try:
        os.mkdir("crafted/crafted_"+str(j+1))
    except:
        print()
    fileName = "crafted/crafted_"+str(j+1)+"/check.mcfunction"
    f = open(fileName, "w+")
    data = f.read()
    f.write(data + "\nexecute as @a[scores={craft_op_ench"+str(j+1)+"=1..}] run scoreboard players add @s craft_op_ench 1\nexecute as @a[scores={craft_op_ench"+str(j+1)+"=1..}] run scoreboard players remove @s craft_op_ench"+str(j+1)+" 1\n")
f.close()
