

fileName = "run_scoreboard.mcfunction"
f = open(fileName, "w+")
f.write("\n")
for j in range(977):
    data = f.read()
    f.write(data + "function crafting_op_enchantments:crafted/crafted/crafted_"+str(j+1)+"/check\n")
f.close()
