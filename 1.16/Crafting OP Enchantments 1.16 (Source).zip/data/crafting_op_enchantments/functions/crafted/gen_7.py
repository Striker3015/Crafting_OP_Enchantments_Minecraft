import os
fileName_t = "crafted_t.mcfunction"
f_t = open(fileName_t, "r+")
data_t = f_t.read()
data_t = data_t.split("\n")

for j in range(977):
    try:
        os.mkdir("crafted/crafted_"+str(j+1))
    except:
        print()
    fileName = "crafted/crafted_"+str(j+1)+"/crafted.mcfunction"
    f = open(fileName, "w+")
    data = f.read()
    f.write(data + "\n"+data_t[j]+"\n")
f.close()
