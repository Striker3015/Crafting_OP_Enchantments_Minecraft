import time
import keyboard

#keys = keyboard.record("esc")
#print(keys)

separator = '+'
keyboard.wait('esc')
for j in range(977):
    print(separator.join(list(str(j+1))))
    i = list(str(j+1))
    l = len(i)
    for e in range(l):
        keyboard.send(str(i[e]))
    #keyboard.send(separator.join(list(str(j+1))))
    keyboard.send("ctrl+left")
    keyboard.send("down")
    keyboard.send("ctrl+right")

