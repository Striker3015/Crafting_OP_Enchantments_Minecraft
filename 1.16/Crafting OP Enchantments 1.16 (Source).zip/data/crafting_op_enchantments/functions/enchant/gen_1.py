
for j in range(36):
    j = j + 1
    fileName = "enchant_"+str(j)+"/enchant_"+str(j)+".mcfunction"
    f = open(fileName, "w+")
    f.write("\n")
    for i in range(99):
        i = 100 - i
        data = f.read()
        f.write(data + "data modify entity @s[nbt={Item:{tag:{crafting_op_enchantments-enchantment_"+str(j)+":"+str((i-1)*10)+"b}}}] Item.tag merge value {crafting_op_enchantments-enchantment_"+str(j)+":"+str(i*10)+"b}\n")
    data = f.read()
    f.write(data + "data modify entity @s[nbt={Item:{tag:{crafting_op_enchantments-enchantment_"+str(j)+":0b}}}] Item.tag merge value {crafting_op_enchantments-enchantment_"+str(j)+":10b}\n\nfunction crafting_op_enchantments:enchant/enchant_"+str(j)+"/enchant_item\n")
    f.close()
