enchant = ["knockback","aqua_affinity","bane_of_arthropods","blast_protection","channeling","depth_strider","efficiency","feather_falling","fire_aspect","fire_protection","flame","fortune","frost_walker","impaling","infinity","looting","loyalty","luck_of_the_sea","lure","mending","multishot","piercing","power","projectile_protection","protection","punch","quick_charge","respiration","riptide","sharpness","silk_touch","smite","soul_speed","sweeping","thorns","unbreaking"]

for j in range(36):
    j = j + 1
    fileName = "enchant_"+str(j)+"/enchant_item.mcfunction"
    f = open(fileName, "w+")
    f.write("\n")
    for i in range(100):
        i = i + 1
        i = i * 10
        data = f.read()
        f.write(data + "execute as @s[nbt={Item:{tag:{crafting_op_enchantments-enchantment_"+str(j)+":"+str(i)+"b}}}] run data modify entity @s Item.tag.Enchantments[{id:\"minecraft:"+ enchant[j-1] +"\"}] merge value {lvl:"+str(i)+"}\n")
    f.close()
