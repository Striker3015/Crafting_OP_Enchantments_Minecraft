armor = ("feet","legs","chest","head")

for j in range(41):
    if (j == 36):
        j = 100
    elif (j == 37):
        j = 101
    elif (j == 38):
        j = 102
    elif (j == 39):
        j = 103
    elif (j == 40):
        j = -106
    fileName = "slot_"+str(j)+"/summon.mcfunction"
    f = open(fileName, "w+")
    data = f.read()
    f.write(data + "\ntag @s remove craft_op_ench_slot_"+str(j)+"\n")
    data = f.read()
    f.write(data + "\nexecute if entity @s[nbt={Inventory:[{Slot:"+str(j)+"b}]}] run execute unless entity @e[type=item,distance=..2,tag=crafting_op_enchantments_item_slot_"+str(j)+"] run summon item ~ ~ ~ {Tags:[\"crafting_op_enchantments_item_slot_"+str(j)+"\"],Invulnerable:1b,Silent:1b,PickupDelay:0,Item:{id:\"minecraft:stone\",Count:1b,tag:{")
    for i in range(36):
        data = f.read()
        if (i == 35):
            f.write(data + "crafting_op_enchantments-enchantment_"+str(i)+":0b")
        else:
            f.write(data + "crafting_op_enchantments-enchantment_"+str(i)+":0b,")
    data = f.read()
    f.write(data + "}}}\nexecute if entity @s[nbt={Inventory:[{Slot:"+str(j)+"b}]}] run data modify entity @e[type=item,distance=..2,tag=crafting_op_enchantments_item_slot_"+str(j)+",limit=1] Item merge from entity @s Inventory[{Slot:"+str(j)+"b}]\nexecute if entity @s[nbt={Inventory:[{Slot:"+str(j)+"b}]}] run execute as @e[type=item,distance=..2,tag=crafting_op_enchantments_item_slot_"+str(j)+"] at @s run function crafting_op_enchantments:inventory/slot_"+str(j)+"/setting_item\n")
    if (j >= 0 and j < 9):
        data = f.read()
        f.write(data + "\nexecute if entity @s[nbt={Inventory:[{Slot:"+str(j)+"b}]}] run item replace entity @s hotbar."+str(j)+" with air\n")
    elif (j >= 9 and j < 36):
        data = f.read()
        f.write(data + "\nexecute if entity @s[nbt={Inventory:[{Slot:"+str(j)+"b}]}] run item replace entity @s inventory."+str(j - 9)+" with air\n")
    elif (j >= 100 and j < 104):
        data = f.read()
        f.write(data + "\nexecute if entity @s[nbt={Inventory:[{Slot:"+str(j)+"b}]}] run item replace entity @s armor."+armor[j - 100]+" with air\n")
    elif (j == -106):
        data = f.read()
        f.write(data + "\nexecute if entity @s[nbt={Inventory:[{Slot:"+str(j)+"b}]}] run item replace entity @s weapon.offhand with air\n")
    f.close()
